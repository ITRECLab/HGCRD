import numpy as np
from math import sqrt, fabs
import datetime as time

dataset = 'douban_book'
DROP_RATE_MAX = 0.05
DROP_RATE_EPOCH = 30
TRAIN_RATE = 0.8
RATEDIM = 10
USERDIM = 30
ITEMDIM = 10
UNUM = 13024
INUM = 22347
USER_METAPATHS = ['ubu', 'ubabu', 'ubpbu', 'ubybu']
ITEM_METAPATHS = ['bub', 'bpb', 'byb']
for i in range(len(USER_METAPATHS)):
    USER_METAPATHS[i] += '_' + str(TRAIN_RATE) + '.embedding'
for i in range(len(ITEM_METAPATHS)):
    ITEM_METAPATHS[i] += '_' + str(TRAIN_RATE) + '.embedding'
TRAINFILE = '../data/yelp/ub_' + str(TRAIN_RATE) + '.train'
TESTFILE = '../data/yelp/ub_' + str(TRAIN_RATE) + '.test'
EPOCHS = 100
DELTA = 0.02
BETA_E = 0.1
BETA_H = 0.1
BETA_P = 2
BETA_W = 0.1
BETA_B = 0.1
REG_U = 1.0
REG_V = 1.0


def load_embedding(metapaths, num):
    X = {}
    for i in range(num):
        X[i] = {}
    metapathdims = []
    ctn = 0
    for metapath in metapaths:
        sourcefile = '../data/douban_book/embeddings/' + metapath
        with open(sourcefile) as infile:
            k = int(infile.readline().strip().split(' ')[1])
            metapathdims.append(k)
            for i in range(num):
                X[i][ctn] = np.zeros(k)
            n = 0
            for line in infile.readlines():
                n += 1
                arr = line.strip().split(' ')
                id = int(arr[0]) - 1
                for j in range(k):
                    X[id][ctn][j] = float(arr[j + 1])
            print('metapath: {}  numbers: {}'.format(metapath, n))
        ctn += 1
    return X, metapathdims


def load_rating(trainfile, testfile):
    R_train = []
    R_test = []
    n = 0
    with open(trainfile) as infile:
        for line in infile.readlines():
            user, item, rating = line.strip().split('\t')
            R_train.append([int(user) - 1, int(item) - 1, int(rating)])
            n += 1
    with open(testfile) as infile:
        for line in infile.readlines():
            user, item, rating = line.strip().split('\t')
            R_test.append([int(user) - 1, int(item) - 1, int(rating)])

    return R_train, R_test


def sigmod(x):
    return 1 / (1 + np.exp(-x))


def drop_rate(epoch):
    max_epoch = DROP_RATE_EPOCH
    drop = np.linspace(0, DROP_RATE_MAX, max_epoch)
    if epoch < max_epoch:
        return drop[epoch]
    else:
        return DROP_RATE_MAX


class HGCRD:
    def __init__(self, unum, inum, ratedim, userdim, itemdim, user_metapaths, item_metapaths, trainfile,
                 testfile, epochs, delta, beta_e, beta_h, beta_p, beta_w, beta_b, reg_u, reg_v):
        self.unum = unum
        self.inum = inum
        self.ratedim = ratedim
        self.userdim = userdim
        self.itemdim = itemdim
        self.epochs = epochs
        self.delta = delta
        self.beta_e = beta_e
        self.beta_h = beta_h
        self.beta_p = beta_p
        self.beta_w = beta_w
        self.beta_b = beta_b
        self.reg_u = reg_u
        self.reg_v = reg_v
        self.user_metapathnum = len(user_metapaths)
        self.item_metapathnum = len(item_metapaths)
        self.E = np.random.randn(self.unum, self.itemdim) * 0.1
        self.H = np.random.randn(self.inum, self.userdim) * 0.1
        self.U = np.random.randn(self.unum, self.ratedim) * 0.1
        self.V = np.random.randn(self.inum, self.ratedim) * 0.1
        self.pu = np.ones((self.unum, self.user_metapathnum)) * 1.0 / self.user_metapathnum
        self.pv = np.ones((self.inum, self.item_metapathnum)) * 1.0 / self.item_metapathnum
        self.X, self.user_metapathdims = load_embedding(user_metapaths, unum)
        print('Load user embeddings finished.')
        self.Y, self.item_metapathdims = load_embedding(item_metapaths, inum)
        print('Load item embeddings finished.')
        self.R, self.T = load_rating(trainfile, testfile)
        print('Load rating finished.')
        print('train size : %d' % len(self.R))
        print('test size : %d' % len(self.T))
        for k in range(self.user_metapathnum):
            self.Wu[k] = np.random.randn(self.userdim, self.user_metapathdims[k]) * 0.1
            self.bu[k] = np.random.randn(self.userdim) * 0.1
        self.Wv = {}
        self.bv = {}
        for k in range(self.item_metapathnum):
            self.Wv[k] = np.random.randn(self.itemdim, self.item_metapathdims[k]) * 0.1
            self.bv[k] = np.random.randn(self.itemdim) * 0.1
        print('训练模型，初始(超)参数设置如下:')
        print('delta: %.2f  beta_e: %.2f  beta_h: %.2f  beta_p: %.2f  beta_w: %.2f  beta_b: %.2f  reg_u: %.2f  '
              'reg_v: %.2f ' % (DELTA, BETA_E, BETA_H, BETA_P, BETA_W, BETA_B, REG_U, REG_V))
        self.trainmodel()

    def cal_u(self, i):
        ui = np.zeros(self.userdim)
        for k in range(self.user_metapathnum):
            ui += self.pu[i][k] * sigmod((self.Wu[k].dot(self.X[i][k]) + self.bu[k]))
        return sigmod(ui)

    def cal_v(self, j):
        vj = np.zeros(self.itemdim)
        for k in range(self.item_metapathnum):
            vj += self.pv[j][k] * sigmod((self.Wv[k].dot(self.Y[j][k]) + self.bv[k]))
        return sigmod(vj)

    def get_rating(self, i, j):
        ui = self.cal_u(i)
        vj = self.cal_v(j)
        return self.U[i, :].dot(self.V[j, :]) + self.reg_u * ui.dot(self.H[j, :]) + self.reg_v * self.E[i, :].dot(vj)

    def maermse(self):
        mae = 0.0
        rmse = 0.0
        n = 0
        for t in self.T:
            n += 1
            i = t[0]
            j = t[1]
            r = t[2]
            r_p = self.get_rating(i, j)
            m = fabs(r_p - r)
            mae += m
            rmse += m * m
        mae = mae * 1.0 / n
        rmse = sqrt(rmse * 1.0 / n)
        return mae, rmse

    def trainmodel(self):
        mae = []
        rmse = []
        perror = 99999
        cerror = 9999
        n = len(self.R)
        print('Start training...')
        starttime = time.datetime.now().replace(microsecond=0)
        for epoch in range(self.epochs):
            total_error = 0.0
            loss_everyR = []
            for e in range(3):
                for t in self.R:
                    i = t[0]
                    j = t[1]
                    rij = t[2]
                    if e == 0:
                        rij_p = self.get_rating(i, j)
                        eij = abs(rij - rij_p)
                        loss_everyR.append(eij)
                        continue
                    elif e == 1:
                        loss_everyR = sorted(loss_everyR)
                        break
                    jiezhi_loss_id = int(len(loss_everyR) * (1 - drop_rate(epoch))) - 1
                    rij_p = self.get_rating(i, j)
                    eij = abs(rij - rij_p)
                    if eij > loss_everyR[jiezhi_loss_id]:
                        continue
                    rij_t = self.get_rating(i, j)
                    eij = rij - rij_t
                    total_error += eij * eij
                    U_g = -eij * self.V[j] + self.beta_e * self.U[i]
                    V_g = -eij * self.U[i] + self.beta_h * self.V[j]
                    self.U[i, :] -= self.delta * U_g
                    self.V[j, :] -= self.delta * V_g
                    ui = self.cal_u(i)
                    for k in range(self.user_metapathnum):
                        x_t = sigmod(self.Wu[k].dot(self.X[i][k]) + self.bu[k])
                        pu_g = self.reg_u * -eij * (ui * (1 - ui) * self.H[j, :]).dot(x_t) + self.beta_p * self.pu[i][k]
                        Wu_g = self.reg_u * -eij * self.pu[i][k] * np.array(
                            [ui * (1 - ui) * x_t * (1 - x_t) * self.H[j, :]]).T.dot(
                            np.array([self.X[i][k]])) + self.beta_w * self.Wu[k + 1]
                        bu_g = self.reg_u * -eij * ui * (1 - ui) * self.pu[i][k] * self.H[j, k] * x_t * (
                                1 - x_t) + self.beta_b * self.bu[k]
                        self.pu[i][k] -= 0.1 * self.delta * pu_g
                        self.Wu[k] -= 0.1 * self.delta * Wu_g
                        self.bu[k] -= 0.1 * self.delta * bu_g
                    H_g = self.reg_u * -eij * ui + self.beta_h * self.H[j, :]
                    self.H[j, :] -= self.delta * H_g
                    vj = self.cal_v(j)
                    for k in range(self.item_metapathnum):
                        y_t = sigmod(self.Wv[k].dot(self.Y[j][k]) + self.bv[k])
                        pv_g = self.reg_v * -eij * (vj * (1 - vj) * self.E[i, :]).dot(y_t) + self.beta_p * self.pv[j][k]
                        Wv_g = self.reg_v * -eij * self.pv[j][k] * np.array(
                            [vj * (1 - vj) * y_t * (1 - y_t) * self.E[i, :]]).T.dot(
                            np.array([self.Y[j][k]]).T) + self.beta_w * self.Wv[k]
                        bv_g = self.reg_v * -eij * vj * (1 - vj) * self.pv[j][k] * self.E[i, :] * y_t * (
                                1 - y_t) + self.beta_b * self.bv[k]
                        self.pv[j][k] -= 0.1 * self.delta * pv_g
                        self.Wv[k] -= 0.1 * self.delta * Wv_g
                        self.bv[k] -= 0.1 * self.delta * bv_g
                    E_g = self.reg_v * -eij * vj + 0.01 * self.E[i, :]
                    self.E[i, :] -= self.delta * E_g
            perror = cerror
            cerror = total_error / n
            self.delta = 0.93 * self.delta
            print('epoch: {}/{}  本次训练的平均误差: {:.4f}'.format(epoch + 1, self.epochs, cerror))
            MAE, RMSE = self.maermse()
            mae.append(MAE)
            rmse.append(RMSE)
            print('本次训练在测试集上的表现，MAE: {:.6f}  RMSE: {:.6f}'.format(MAE, RMSE))
            print('------------------------')
            if abs(perror - cerror) < 0.0001:
                break
        endtime = time.datetime.now().replace(microsecond=0)
        print('训练结束，总用时: {}'.format(endtime - starttime))
        print('最优结果为，MAE: {:.4f}  RMSE: {:.4f}'.format(min(mae), min(rmse)))


if __name__ == "__main__":
    print('train_rate: %.1f' % TRAIN_RATE)
    print('ratedim: %d  userdim: %d  itemdim: %d' % (RATEDIM, USERDIM, ITEMDIM))
    print('max_epochs: %d' % EPOCHS)
    model_instance = HGCRD(UNUM, INUM, RATEDIM, USERDIM, ITEMDIM, USER_METAPATHS, ITEM_METAPATHS, TRAINFILE, TESTFILE,
                           EPOCHS, DELTA, BETA_E, BETA_H, BETA_P, BETA_W, BETA_B, REG_U, REG_V)
