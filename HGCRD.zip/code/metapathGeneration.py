#!/usr/bin/python
import numpy as np

train_rate = 0.8
dataset = 'douban_book'


class MetapathGeneration:
    def __init__(self, unum_db, bnum_db, anum_db, pnum_db, ynum_db):
        self.unum = unum_db + 1
        self.bnum = bnum_db + 1
        self.anum = anum_db + 1
        self.pnum = pnum_db + 1
        self.ynum = ynum_db + 1
        ub = self.load_ub_db('../data/douban_book/ub_' + str(train_rate) + '.train')
        self.get_UBU_db(ub, '../data/douban_book/metapath/ubu_' + str(train_rate) + '.txt')
        self.get_BUB_db(ub, '../data/douban_book/metapath/bub_' + str(train_rate) + '.txt')
        self.get_BPB_db('../data/douban_book/bp.dat',
                        '../data/douban_book/metapath/bpb_' + str(train_rate) + '.txt')
        self.get_BYB_db('../data/douban_book/by.dat',
                        '../data/douban_book/metapath/byb_' + str(train_rate) + '.txt')
        self.get_UBABU_db(ub, '../data/douban_book/ba.dat',
                          '../data/douban_book/metapath/ubabu_' + str(train_rate) + '.txt')
        self.get_UBPBU_db(ub, '../data/douban_book/bp.dat',
                          '../data/douban_book/metapath/ubpbu_' + str(train_rate) + '.txt')
        self.get_UBYBU_db(ub, '../data/douban_book/by.dat',
                          '../data/douban_book/metapath/ubybu_' + str(train_rate) + '.txt')

    def load_ub_db(self, umfile):
        um = np.zeros((self.unum, self.bnum))
        with open(umfile, 'r') as infile:
            for line in infile.readlines():
                user, item, rating = line.strip().split('\t')
                um[int(user)][int(item)] = 1
        return um

    def get_UBU_db(self, ub, targetfile):
        print('UBU...')
        uu = ub.dot(ub.T)
        print(uu.shape)
        print('writing to file...')
        total = 0
        with open(targetfile, 'w') as outfile:
            for i in range(uu.shape[0]):
                for j in range(uu.shape[1]):
                    if uu[i][j] != 0 and i != j:
                        outfile.write(str(i) + '\t' + str(j) + '\t' + str(int(uu[i + 1][j + 1])) + '\n')
                        total += 1
        print('total = %d' % total)

    def get_BUB_db(self, ub, targetfile):
        print('BUB...')
        uu = ub.T.dot(ub)
        print(uu.shape)
        print('writing to file...')
        total = 0
        with open(targetfile, 'w') as outfile:
            for i in range(uu.shape[0]):
                for j in range(uu.shape[1]):
                    if uu[i][j] != 0 and i != j:
                        outfile.write(str(i) + '\t' + str(j) + '\t' + str(int(uu[i][j])) + '\n')
                        total += 1
        print('total = %d' % total)

    def get_BPB_db(self, mafile, targetfile):
        print('BPB..')
        ma = np.zeros((self.bnum, self.pnum))
        with open(mafile) as infile:
            for line in infile.readlines():
                m, d = line.strip().split('\t')
                ma[int(m)][int(d)] = 1

        mm = ma.dot(ma.T)
        print('writing to file...')
        total = 0
        with open(targetfile, 'w') as outfile:
            for i in range(mm.shape[0])[1:]:
                for j in range(mm.shape[1])[1:]:
                    if mm[i][j] != 0 and i != j:
                        outfile.write(str(i) + '\t' + str(j) + '\t' + str(int(mm[i][j])) + '\n')
                        total += 1
        print('total = %d' % total)

    def get_BYB_db(self, mafile, targetfile):
        print('BYB..')
        ma = np.zeros((self.bnum, self.ynum))
        with open(mafile) as infile:
            for line in infile.readlines():
                m, d = line.strip().split('\t')
                ma[int(m)][int(d)] = 1
        mm = ma.dot(ma.T)
        print('writing to file...')
        total = 0
        with open(targetfile, 'w') as outfile:
            for i in range(mm.shape[0])[1:]:
                for j in range(mm.shape[1])[1:]:
                    if mm[i][j] != 0 and i != j:
                        outfile.write(str(i) + '\t' + str(j) + '\t' + str(int(mm[i][j])) + '\n')
                        total += 1
        print('total = %d' % total)

    def get_UBABU_db(self, ub, mdfile, targetfile):
        print('UBABU...')
        md = np.zeros((self.bnum, self.anum))
        with open(mdfile, 'r') as infile:
            for line in infile.readlines():
                m, d = line.strip().split('\t')
                md[int(m)][int(d)] = 1
        uu = ub.dot(md).dot(ub.T)
        print('writing to file...')
        total = 0
        with open(targetfile, 'w') as outfile:
            for i in range(uu.shape[0]):
                for j in range(uu.shape[1]):
                    if uu[i][j] != 0 and i != j:
                        outfile.write(str(i) + '\t' + str(j) + '\t' + str(int(uu[i][j])) + '\n')
                        total += 1
        print('total = %d' % total)

    def get_UBPBU_db(self, ub, mdfile, targetfile):
        print('UBPBU...')
        md = np.zeros((self.bnum, self.pnum))
        with open(mdfile, 'r') as infile:
            for line in infile.readlines():
                m, d = line.strip().split('\t')
                md[int(m)][int(d)] = 1

        uu = ub.dot(md).dot(md.T).dot(ub.T)
        print('writing to file...')
        total = 0
        with open(targetfile, 'w') as outfile:
            for i in range(uu.shape[0]):
                for j in range(uu.shape[1]):
                    if uu[i][j] != 0 and i != j:
                        outfile.write(str(i) + '\t' + str(j) + '\t' + str(int(uu[i][j])) + '\n')
                        total += 1
        print('total = %d' % total)

    def get_UBYBU_db(self, ub, mdfile, targetfile):
        md = np.zeros((self.bnum, self.ynum))
        with open(mdfile, 'r') as infile:
            for line in infile.readlines():
                m, d = line.strip().split('\t')
                md[int(m)][int(d)] = 1
        uu = ub.dot(md).dot(md.T).dot(ub.T)
        total = 0
        with open(targetfile, 'w') as outfile:
            for i in range(uu.shape[0]):
                for j in range(uu.shape[1]):
                    if uu[i][j] != 0 and i != j:
                        outfile.write(str(i) + '\t' + str(j) + '\t' + str(int(uu[i][j])) + '\n')
                        total += 1
        print('total = %d' % total)


if __name__ == '__main__':
    MetapathGeneration(unum_db=13024, bnum_db=22347, anum_db=10805, pnum_db=1815, ynum_db=64)
